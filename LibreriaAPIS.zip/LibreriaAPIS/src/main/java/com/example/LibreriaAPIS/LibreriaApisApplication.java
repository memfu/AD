package com.example.LibreriaAPIS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibreriaApisApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibreriaApisApplication.class, args);
	}

}
